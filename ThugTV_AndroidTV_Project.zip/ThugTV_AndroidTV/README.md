# ThugTV for Android TV

This is an Android Studio project that wraps `https://thugtv.online/` in a full-screen Android WebView.

## Included
- Android TV Leanback launcher entry
- Landscape full-screen layout
- JavaScript, DOM storage and cookies enabled
- HTML5 video fullscreen callbacks
- Android TV remote navigation is passed to the web page
- Back button navigates browser history

## Build the APK
1. Install Android Studio (with Android SDK Platform 35 and Build Tools).
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the APK at `app/build/outputs/apk/debug/app-debug.apk`.

Or from a terminal with Gradle installed:
```bash
gradle assembleDebug
```

## Install on Android TV
Enable Developer options and USB/network debugging, then install:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Notes
- The app requires an internet connection.
- Playback depends on the website's own player, provider availability, and Android WebView compatibility.
- Some DRM-protected or provider-restricted streams may not play in WebView.
- Only use the app to access content you are legally entitled to view.

## Build automatically on GitHub (without installing Android Studio)
1. Create a new GitHub repository and upload the contents of this project.
2. Open the repository's **Actions** tab.
3. Select **Build ThugTV APK** and click **Run workflow** (or push to `main`).
4. When the workflow finishes, open the run and download the `ThugTV-AndroidTV-APK` artifact.
5. Extract the downloaded artifact; it contains `app-debug.apk`.
